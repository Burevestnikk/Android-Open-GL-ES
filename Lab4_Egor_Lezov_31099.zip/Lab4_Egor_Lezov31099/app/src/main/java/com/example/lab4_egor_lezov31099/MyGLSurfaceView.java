package com.example.lab4_egor_lezov31099;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.KeyEvent;
import android.view.MotionEvent;

public class MyGLSurfaceView extends GLSurfaceView {
    MyGLRenderer renderer;

    private final float TOUCH_SCALE_FACTOR = 180.0f / 320.0f;
    public MyGLSurfaceView(Context context) {
        super(context);
        renderer = new MyGLRenderer(context);
        this.setRenderer(renderer);
        this.requestFocus();
        this.setFocusableInTouchMode(true);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent evt) {
        switch(keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                renderer.speedY -= 0.1f;
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                renderer.speedY += 0.1f;
                break;
            case KeyEvent.KEYCODE_DPAD_UP:
                renderer.speedX -= 0.1f;
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                renderer.speedX += 0.1f;
                break;
            case KeyEvent.KEYCODE_A:
                renderer.z -= 0.2f;
                break;
            case KeyEvent.KEYCODE_Z:
                renderer.z += 0.2f;
                break;
        }
        return true;
    }

    private float previousX, previousY, previousDistance;

    @Override
    public boolean onTouchEvent(final MotionEvent evt) {
        float currentX = evt.getX();
        float currentY = evt.getY();
        float deltaX, deltaY, distance;
        int action = evt.getAction() & MotionEvent.ACTION_MASK;
        int pointerCount = evt.getPointerCount();
        float newZoom;
        switch (action) {
            case MotionEvent.ACTION_MOVE:
                deltaX = currentX - previousX;
                deltaY = currentY - previousY;
                if (pointerCount == 2) {
                    float x1 = evt.getX(0);
                    float y1 = evt.getY(0);
                    float x2 = evt.getX(1);
                    float y2 = evt.getY(1);
                    float newDistance = (float) Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

                    if (previousDistance != -1f) {
                        distance = newDistance - previousDistance;
                        newZoom = renderer.z + distance * 0.001f;
                        renderer.z = newZoom;
                    }

                    previousDistance = newDistance;
                } else {
                    renderer.angleX += deltaY * TOUCH_SCALE_FACTOR;
                    renderer.angleY += deltaX * TOUCH_SCALE_FACTOR;
                }
        }
        previousX = currentX;
        previousY = currentY;
        return true;
    }

}

